package com.koreantv.item;

public class ItemVideo {
    private String id;
    private String videoType;
    private String videoTitle;
    private String videoUrl;
    private String videoId;
    private String videoThumbnailB;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVideoType() {
        return videoType;
    }

    public void setVideoType(String videoType) {
        this.videoType = videoType;
    }

    public String getVideoTitle() {
        return videoTitle;
    }

    public void setVideoTitle(String videoTitle) {
        this.videoTitle = videoTitle;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public String getVideoId() {
        return videoId;
    }

    public void setVideoId(String videoId) {
        this.videoId = videoId;
    }

    public String getVideoThumbnailB() {
        return videoThumbnailB;
    }

    public void setVideoThumbnailB(String videoThumbnailB) {
        this.videoThumbnailB = videoThumbnailB;
    }

}
